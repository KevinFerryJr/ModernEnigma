__version__ = '0.0.1'
from ModernEnigma import enigma